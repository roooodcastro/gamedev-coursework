#include "AudioManager.h"

AudioManager::AudioManager(void) {
}

AudioManager::~AudioManager(void) {
}