#include "GameRenderer.h"


GameRenderer::GameRenderer(void)
{
}


GameRenderer::~GameRenderer(void)
{
}
