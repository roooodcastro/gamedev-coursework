#include "BoundingBox.h"

BoundingBox::BoundingBox(void) {
}

BoundingBox::BoundingBox(const BoundingBox &copy) {
}

BoundingBox::~BoundingBox(void) {
}

BoundingBox &BoundingBox::operator=(const BoundingBox &other) {
	return *this;
}