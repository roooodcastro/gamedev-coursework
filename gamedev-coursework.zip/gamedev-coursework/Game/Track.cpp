#include "Track.h"

Track::Track(void) {
}

Track::~Track(void) {
}