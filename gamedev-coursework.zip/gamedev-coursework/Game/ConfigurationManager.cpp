#include "ConfigurationManager.h"

ConfigurationManager::ConfigurationManager(void) {
}

ConfigurationManager::~ConfigurationManager(void) {
}