#pragma once
class GameRenderer
{
public:
	GameRenderer(void);
	~GameRenderer(void);
};

