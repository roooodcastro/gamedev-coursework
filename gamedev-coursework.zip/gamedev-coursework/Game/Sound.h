#pragma once

class Sound {
public:
	Sound(void);
	~Sound(void);
};

