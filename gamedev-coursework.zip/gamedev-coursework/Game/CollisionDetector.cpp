#include "CollisionDetector.h"

CollisionDetector::CollisionDetector(void) {
}

CollisionDetector::~CollisionDetector(void) {
}