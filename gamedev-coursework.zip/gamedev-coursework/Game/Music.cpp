#include "Music.h"

Music::Music(void) {
}

Music::~Music(void) {
}