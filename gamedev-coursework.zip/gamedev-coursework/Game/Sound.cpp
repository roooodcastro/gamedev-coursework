#include "Sound.h"

Sound::Sound(void) {
}

Sound::~Sound(void) {
}
